try {
    (function() {
        var ctId = +new Date(),
            dtc = VWO._.dtc = VWO._.dtc || {
                ctId: ctId,
                js: {},
                tag: []
            };
        dtc.js[ctId] = function() {
            var cb = function() {
                setTimeout(function() {
                    for (var i = 0; i < VWO._.dtc.tag.length; i++) {
                        VWO._.coreLib.lS(VWO._.dtc.tag[i])
                    }
                }, 5000)
            };
            if (document.readyState == 'complete') cb();
            else window.addEventListener('load', cb)
        };
        dtc.sC = function() {
            return _vwo_s().f_e(_vwo_s().dt(), 'mobile')
        };;
    })();;
    VWO._.dtc.tC = function() {
        return _vwo_t.cm('eO', 'js', VWO._.dtc.ctId);
    };
    window.VWO = window.VWO || [];
    window.VWO.data = window.VWO.data || {};
    window.VWO.data.ts = 1625410428;
    (function() {
        window.VWO = window.VWO || [];
        var pollInterval = 100;
        var _vis_data = {};
        var intervalObj = {};
        var analyticsTimerObj = {};
        var experimentListObj = {};
        window.VWO.push(["onVariationApplied", function(data) {
            if (!data) {
                return
            }
            var expId = data[1],
                variationId = data[2];
            if (expId && variationId && ["VISUAL_AB", "VISUAL", "SPLIT_URL"].indexOf(window._vwo_exp[expId].type) > -1) {}
        }])
    })();
    window.VWO.data.vi = window.VWO.data.vi || {
        "de": "Android",
        "dt": "mobile",
        "br": "Chrome",
        "os": "Other"
    };
    window.VWO.push(['updateSettings', {
        "27": [{
            "globalCode": {},
            "goals": {
                "1": {
                    "urlRegex": "^https\\:\\\/\\\/sonarqube\\.org\\\/developer\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarcloud\\.io\\\/sessions\\\/new\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarlint\\.org\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                }
            },
            "clickmap": 1,
            "sections": {
                "1": {
                    "path": "",
                    "segmentObj": {},
                    "variations": {
                        "2": "https:\/\/www.sonarsource.com\/cpp-bis\/",
                        "1": "https:\/\/www.sonarsource.com\/cpp\/"
                    },
                    "variationsRegex": {
                        "2": "^https\\:\\\/\\\/sonarsource\\.com\\\/cpp\\-bis\\\/?(?:[\\?#].*)?$",
                        "1": "^https\\:\\\/\\\/sonarsource\\.com\\\/cpp\\\/?(?:[\\?#].*)?$"
                    },
                    "segment": {
                        "2": 1,
                        "1": 1
                    }
                }
            },
            "ps": true,
            "urlRegex": "^https\\:\\\/\\\/sonarsource\\.com\\\/cpp\\\/?(?:[\\?#].*)?$",
            "segment_code": "true",
            "exclude_url": "",
            "multiple_domains": 0,
            "comb_n": {
                "2": "Variation-1",
                "1": "Control"
            },
            "pc_traffic": 100,
            "pgre": true,
            "ibe": 1,
            "name": "Campaign-27",
            "combs": {
                "2": 0.5,
                "1": 0.5
            },
            "ss": null,
            "version": 4,
            "manual": false,
            "status": "RUNNING",
            "type": "SPLIT_URL"
        }],
        "26": [{
            "globalCode": {},
            "goals": {
                "2": {
                    "urlRegex": "^https\\:\\\/\\\/sonarqube\\.org\\\/forms\\\/success\\-developer\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarqube\\.org\\\/forms\\\/success\\-enterprise\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/forms\\\/success\\-data\\-center\\-edition\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                },
                "1": {
                    "urlRegex": "^https\\:\\\/\\\/sonarqube\\.org\\\/developer\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarqube\\.org\\\/enterprise\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/plans\\-and\\-pricing\\\/data\\-center\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                }
            },
            "clickmap": 1,
            "sections": {
                "1": {
                    "path": "",
                    "variations": {
                        "2": "[{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"editElement\\\",\\\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\\\"); vwo_debug*\\\/(el=vwo_$(\\\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\\\")).html(\\\"Start Free Trial\\\");\",\"xpath\":\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\"},{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"editElement\\\",\\\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\"); vwo_debug*\\\/(el=vwo_$(\\\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\")).html(\\\"Start Free Trial\\\");\",\"xpath\":\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\"}]",
                        "3": "[{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"editElement\\\",\\\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\\\"); vwo_debug*\\\/(el=vwo_$(\\\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\\\")).html(\\\"Discover Now\\\");\",\"xpath\":\".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)\"},{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"editElement\\\",\\\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\"); vwo_debug*\\\/(el=vwo_$(\\\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\")).html(\\\"Discover Now\\\");\",\"xpath\":\".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\"},{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"editElement\\\",\\\".downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\"); vwo_debug*\\\/(el=vwo_$(\\\".downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\\\")).html(\\\"Discover Now\\\");\",\"xpath\":\".downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)\"}]",
                        "1": "[]"
                    },
                    "segment": {
                        "2": 1,
                        "3": 1,
                        "1": 1
                    },
                    "segmentObj": {}
                }
            },
            "ps": true,
            "urlRegex": "^https\\:\\\/\\\/sonarqube\\.org\\\/downloads\\\/?(?:[\\?#].*)?$",
            "segment_code": "true",
            "exclude_url": "",
            "multiple_domains": 0,
            "comb_n": {
                "2": "Variation-1",
                "3": "Variation-2",
                "1": "Control"
            },
            "pc_traffic": 100,
            "pgre": true,
            "ibe": 1,
            "muts": {
                "post": {
                    "enabled": true
                }
            },
            "name": "Campaign-26",
            "combs": {
                "2": 0.333333,
                "3": 0.333333,
                "1": 0.333333
            },
            "ss": null,
            "version": 4,
            "manual": false,
            "status": "RUNNING",
            "type": "VISUAL_AB"
        }],
        "25": [{
            "globalCode": {},
            "goals": {
                "2": {
                    "urlRegex": "^https\\:\\\/\\\/sonarsource\\.com\\\/plans\\-and\\-pricing\\\/developer\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/plans\\-and\\-pricing\\\/enterprise\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/plans\\-and\\-pricing\\\/data\\-center\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                },
                "3": {
                    "urlRegex": "^https\\:\\\/\\\/sonarsource\\.com\\\/forms\\\/success\\-developer\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/forms\\\/success\\-enterprise\\-edition\\\/?(?:[\\?#].*)?$|^https\\:\\\/\\\/sonarsource\\.com\\\/forms\\\/success\\-data\\-center\\-edition\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                },
                "1": {
                    "urlRegex": "^https\\:\\\/\\\/sonarsource\\.com\\\/forms\\\/success\\\/?(?:[\\?#].*)?$",
                    "type": "SEPARATE_PAGE",
                    "excludeUrl": ""
                }
            },
            "clickmap": 1,
            "sections": {
                "1": {
                    "path": "",
                    "variations": {
                        "2": "[{\"js\":\"var el,ctx=vwo_$(x);\\n\\\/*vwo_debug log(\\\"moveResize\\\",\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)\\\"); vwo_debug*\\\/(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)\\\")).vwoCss({left:\\\"0px !important\\\",top:\\\"32px !important\\\",zIndex:\\\"auto !important\\\",position:\\\"relative !important\\\",display:\\\"block !important\\\"}),el.before(\\\"<h2>Subscription and licensing FAQ<\\\/h2>\\\"),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\")).after('<a class=\\\"btn btn-red text-center\\\" href=\\\"https:\\\/\\\/www.sonarsource.com\\\/plans-and-pricing\\\/enterprise\\\/\\\" style=\\\"width: 247px; transform-origin: 123.5px 22px; perspective-origin: 123.5px 22px; inline-size: 247px; box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px 0px inset;\\\"><div style=\\\"width: 207px; transform-origin: 103.5px 22px; perspective-origin: 103.5px 22px; inline-size: 207px;\\\"><p style=\\\"width: 207px; transform-origin: 103.5px 22px; perspective-origin: 103.5px 22px; inline-size: 207px;\\\">Learn more<\\\/p><\\\/div><\\\/a>'),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\")).after(\\\"<h2>Not sure what edition is right for you? Contact us today!<\\\/h2>\\\"),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1) > div:nth-of-type(1) > p:nth-of-type(1)\\\")).vwoCss({\\\"text-align\\\":\\\"center !important\\\"}),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\")).each((function(){var t=vwo_$(\\\"#SonarQube > div:nth-of-type(2)\\\"),o=t.nonEmptyContents().eq(1);o.length?o.before(this):t.append(this)})),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(2)\\\")).vwoCss({display:\\\"none !important\\\"}),el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\"),vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\").each((function(){vwo_$(this).vwoAttr(\\\"href\\\",\\\"https:\\\/\\\/www.sonarsource.com\\\/company\\\/contact\\\/\\\"),vwo_$(this).vwoAttr(\\\"style\\\",\\\"width: 247px; transform-origin: 123.5px 22px; perspective-origin: 123.5px 22px; inline-size: 247px; box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px 0px inset; left: 39% !important; top: 0px !important; position: relative !important; display: inline-block !important;\\\"),vwo_$(this).children().eq(0).children().eq(0).vwoAttr(\\\"class\\\",\\\"\\\"),vwo_$(this).children().eq(0).children().eq(0).nonEmptyContents().eq(0).replaceWith(document.createTextNode(\\\"Contact Us\\\"))})),el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\"),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1) > div:nth-of-type(1) > p:nth-of-type(1)\\\")).html(\\\"Contact Us\\\"),el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\"),vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\").each((function(){vwo_$(this).nonEmptyContents().eq(0).replaceWith('<a href=\\\"https:\\\/\\\/www.sonarsource.com\\\/forms\\\/contact-us.html\\\">Not sure what edition is right for you? Contact us today!<\\\/a>')})),el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\"),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\")).vwoAttr({href:\\\"https:\\\/\\\/www.sonarsource.com\\\/forms\\\/contact-us.html\\\"}),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)\\\")).after('<a href=\\\"https:\\\/\\\/www.sonarsource.com\\\/forms\\\/contact-us.html\\\" style=\\\"text-align: center; line-height: 26px; font-weight: 700; font-size: 26px;\\\">Contact us today!<\\\/a>'),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)\\\")).vwoCss({display:\\\"none !important\\\"}),el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)\\\"),vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)\\\").each((function(){vwo_$(this).nonEmptyContents().eq(0).replaceWith(document.createTextNode(\\\"Not sure what edition is right for you?\\\"))})),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)\\\")).html(\\\"Not sure what edition is right for you?\\\").vwoAttr({href:\\\"\\\"}),el.vwoCss({display:\\\"none !important\\\"}),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2)\\\")).before('<h2 style=\\\"left: 0px !important; top: 32px !important; position: relative !important; display: block !important; transform-origin: 578px 13px; text-align: center; perspective-origin: 578px 13px; margin-bottom: 26px; margin-block-end: 26px; line-height: 26px; height: 26px; font-size: 26px; block-size: 26px;\\\">Subscription and licensing FAQ<\\\/h2>'),(el=vwo_$(\\\"#SonarQube > h2:nth-of-type(1)\\\")).vwoCss({left:\\\"0px !important\\\",top:\\\"0px !important\\\",zIndex:\\\"auto !important\\\",position:\\\"relative !important\\\",display:\\\"block !important\\\"}),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)\\\")).vwoCss({left:\\\"0px !important\\\",top:\\\"64px !important\\\",zIndex:\\\"auto !important\\\",position:\\\"relative !important\\\",display:\\\"block !important\\\",height:\\\"26px !important\\\",width:\\\"1156px !important\\\"}),(el=vwo_$(\\\"#SonarQube > div:nth-of-type(2) > section:nth-of-type(1)\\\")).vwoCss({left:\\\"0px !important\\\",top:\\\"64px !important\\\",zIndex:\\\"auto !important\\\",position:\\\"relative !important\\\",display:\\\"flex !important\\\"}),(el=vwo_$(\\\"#SonarQube > h2:nth-of-type(1)\\\")).html(\\\"Not sure which edition is right for you?\\\");\",\"xpath\":\"#SonarQube\"}]",
                        "1": "[]"
                    },
                    "segment": {
                        "2": 1,
                        "1": 1
                    },
                    "segmentObj": {}
                }
            },
            "ps": true,
            "urlRegex": "^https\\:\\\/\\\/sonarsource\\.com\\\/plans\\-and\\-pricing\\\/?(?:[\\?#].*)?$",
            "segment_code": "true",
            "exclude_url": "",
            "multiple_domains": 0,
            "comb_n": {
                "2": "Variation-1",
                "1": "Control"
            },
            "pc_traffic": 100,
            "pgre": true,
            "ibe": 1,
            "muts": {
                "post": {
                    "enabled": true
                }
            },
            "name": "Campaign-25",
            "combs": {
                "2": 0.5,
                "1": 0.5
            },
            "ss": null,
            "version": 4,
            "manual": false,
            "status": "RUNNING",
            "type": "VISUAL_AB"
        }]
    }, {}]);;
    _vwo_exp[27].sections[1].cspCompVariations = _vwo_exp[27].sections[1].cspCompVariations || {};
    _vwo_exp[27].sections[1].cspCompVariations[2] = _vwo_exp[27].sections[1].cspCompVariations[2] || [];
    _vwo_exp[27].sections[1].cspCompVariations = _vwo_exp[27].sections[1].cspCompVariations || {};
    _vwo_exp[27].sections[1].cspCompVariations[1] = _vwo_exp[27].sections[1].cspCompVariations[1] || [];
    _vwo_exp[27].sections[1].cspSegmentCode = _vwo_exp[27].sections[1].cspCompSegment || {};
    _vwo_exp[27].sections[1].cspSegmentCode[2] = function() {
        return 1;
    };
    _vwo_exp[27].sections[1].cspSegmentCode[1] = function() {
        return 1;
    };
    _vwo_exp[26].sections[1].cspCompVariations = _vwo_exp[26].sections[1].cspCompVariations || {};
    _vwo_exp[26].sections[1].cspCompVariations[2] = _vwo_exp[26].sections[1].cspCompVariations[2] || [];
    _vwo_exp[26].sections[1].cspCompVariations[2].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("editElement",".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)"); vwo_debug*/
            (el = vwo_$(".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)")).html("Start Free Trial");;
        })('.downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)')
    });
    _vwo_exp[26].sections[1].cspCompVariations[2].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("editElement",".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)"); vwo_debug*/
            (el = vwo_$(".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)")).html("Start Free Trial");;
        })('.downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)')
    });
    _vwo_exp[26].sections[1].cspCompVariations = _vwo_exp[26].sections[1].cspCompVariations || {};
    _vwo_exp[26].sections[1].cspCompVariations[3] = _vwo_exp[26].sections[1].cspCompVariations[3] || [];
    _vwo_exp[26].sections[1].cspCompVariations[3].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("editElement",".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)"); vwo_debug*/
            (el = vwo_$(".downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)")).html("Discover Now");;
        })('.downloads-developer > div:nth-of-type(1) > div:nth-of-type(4) > a:nth-of-type(1)')
    });
    _vwo_exp[26].sections[1].cspCompVariations[3].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("editElement",".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)"); vwo_debug*/
            (el = vwo_$(".downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)")).html("Discover Now");;
        })('.downloads-enterprise > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)')
    });
    _vwo_exp[26].sections[1].cspCompVariations[3].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("editElement",".downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)"); vwo_debug*/
            (el = vwo_$(".downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)")).html("Discover Now");;
        })('.downloads-data-center > div:nth-of-type(1) > div:nth-of-type(3) > a:nth-of-type(1)')
    });
    _vwo_exp[26].sections[1].cspCompVariations = _vwo_exp[26].sections[1].cspCompVariations || {};
    _vwo_exp[26].sections[1].cspCompVariations[1] = _vwo_exp[26].sections[1].cspCompVariations[1] || [];
    _vwo_exp[26].sections[1].cspSegmentCode = _vwo_exp[26].sections[1].cspCompSegment || {};
    _vwo_exp[26].sections[1].cspSegmentCode[2] = function() {
        return 1;
    };
    _vwo_exp[26].sections[1].cspSegmentCode[3] = function() {
        return 1;
    };
    _vwo_exp[26].sections[1].cspSegmentCode[1] = function() {
        return 1;
    };
    _vwo_exp[25].sections[1].cspCompVariations = _vwo_exp[25].sections[1].cspCompVariations || {};
    _vwo_exp[25].sections[1].cspCompVariations[2] = _vwo_exp[25].sections[1].cspCompVariations[2] || [];
    _vwo_exp[25].sections[1].cspCompVariations[2].push(function() {
        (function(x) {
            var el, ctx = vwo_$(x);
            /*vwo_debug log("moveResize","#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)"); vwo_debug*/
            (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)")).vwoCss({
                left: "0px !important",
                top: "32px !important",
                zIndex: "auto !important",
                position: "relative !important",
                display: "block !important"
            }), el.before("<h2>Subscription and licensing FAQ</h2>"), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)")).after('<a class="btn btn-red text-center" href="https://www.sonarsource.com/plans-and-pricing/enterprise/" style="width: 247px; transform-origin: 123.5px 22px; perspective-origin: 123.5px 22px; inline-size: 247px; box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px 0px inset;"><div style="width: 207px; transform-origin: 103.5px 22px; perspective-origin: 103.5px 22px; inline-size: 207px;"><p style="width: 207px; transform-origin: 103.5px 22px; perspective-origin: 103.5px 22px; inline-size: 207px;">Learn more</p></div></a>'), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)")).after("<h2>Not sure what edition is right for you? Contact us today!</h2>"), (el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1) > div:nth-of-type(1) > p:nth-of-type(1)")).vwoCss({
                "text-align": "center !important"
            }), (el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)")).each((function() {
                var t = vwo_$("#SonarQube > div:nth-of-type(2)"),
                    o = t.nonEmptyContents().eq(1);
                o.length ? o.before(this) : t.append(this)
            })), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(2)")).vwoCss({
                display: "none !important"
            }), el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)"), vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)").each((function() {
                vwo_$(this).vwoAttr("href", "https://www.sonarsource.com/company/contact/"), vwo_$(this).vwoAttr("style", "width: 247px; transform-origin: 123.5px 22px; perspective-origin: 123.5px 22px; inline-size: 247px; box-shadow: rgba(0, 0, 0, 0.25) 0px 2px 4px 0px inset; left: 39% !important; top: 0px !important; position: relative !important; display: inline-block !important;"), vwo_$(this).children().eq(0).children().eq(0).vwoAttr("class", ""), vwo_$(this).children().eq(0).children().eq(0).nonEmptyContents().eq(0).replaceWith(document.createTextNode("Contact Us"))
            })), el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)"), (el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1) > div:nth-of-type(1) > p:nth-of-type(1)")).html("Contact Us"), el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)"), vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)").each((function() {
                vwo_$(this).nonEmptyContents().eq(0).replaceWith('<a href="https://www.sonarsource.com/forms/contact-us.html">Not sure what edition is right for you? Contact us today!</a>')
            })), el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)"), (el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)")).vwoAttr({
                href: "https://www.sonarsource.com/forms/contact-us.html"
            }), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1)")).after('<a href="https://www.sonarsource.com/forms/contact-us.html" style="text-align: center; line-height: 26px; font-weight: 700; font-size: 26px;">Contact us today!</a>'), (el = vwo_$("#SonarQube > div:nth-of-type(2) > a:nth-of-type(1)")).vwoCss({
                display: "none !important"
            }), el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)"), vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)").each((function() {
                vwo_$(this).nonEmptyContents().eq(0).replaceWith(document.createTextNode("Not sure what edition is right for you?"))
            })), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(1) > a:nth-of-type(1)")).html("Not sure what edition is right for you?").vwoAttr({
                href: ""
            }), el.vwoCss({
                display: "none !important"
            }), (el = vwo_$("#SonarQube > div:nth-of-type(2)")).before('<h2 style="left: 0px !important; top: 32px !important; position: relative !important; display: block !important; transform-origin: 578px 13px; text-align: center; perspective-origin: 578px 13px; margin-bottom: 26px; margin-block-end: 26px; line-height: 26px; height: 26px; font-size: 26px; block-size: 26px;">Subscription and licensing FAQ</h2>'), (el = vwo_$("#SonarQube > h2:nth-of-type(1)")).vwoCss({
                left: "0px !important",
                top: "0px !important",
                zIndex: "auto !important",
                position: "relative !important",
                display: "block !important"
            }), (el = vwo_$("#SonarQube > div:nth-of-type(2) > h2:nth-of-type(3)")).vwoCss({
                left: "0px !important",
                top: "64px !important",
                zIndex: "auto !important",
                position: "relative !important",
                display: "block !important",
                height: "26px !important",
                width: "1156px !important"
            }), (el = vwo_$("#SonarQube > div:nth-of-type(2) > section:nth-of-type(1)")).vwoCss({
                left: "0px !important",
                top: "64px !important",
                zIndex: "auto !important",
                position: "relative !important",
                display: "flex !important"
            }), (el = vwo_$("#SonarQube > h2:nth-of-type(1)")).html("Not sure which edition is right for you?");;
        })('#SonarQube')
    });
    _vwo_exp[25].sections[1].cspCompVariations = _vwo_exp[25].sections[1].cspCompVariations || {};
    _vwo_exp[25].sections[1].cspCompVariations[1] = _vwo_exp[25].sections[1].cspCompVariations[1] || [];
    _vwo_exp[25].sections[1].cspSegmentCode = _vwo_exp[25].sections[1].cspCompSegment || {};
    _vwo_exp[25].sections[1].cspSegmentCode[2] = function() {
        return 1;
    };
    _vwo_exp[25].sections[1].cspSegmentCode[1] = function() {
        return 1;
    };;;;
} catch (e) {
    _vwo_code.finish();
    _vwo_code.removeLoaderAndOverlay && _vwo_code.removeLoaderAndOverlay();
    var b = new Image;
    b.src = "https://dev.visualwebsiteoptimizer.com/e.gif?a=555633&s=settings.js&e=" + encodeURIComponent(e && e.message && e.message.substring(0, 1000))
}